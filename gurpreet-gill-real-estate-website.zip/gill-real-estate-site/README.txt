GURPREET GILL — REAL ESTATE WEBSITE STARTER

Files:
- index.html: responsive one-page website
- assets/agent-photo.jpg: cropped photo from supplied business card
- assets/hero-home.png: illustrative hero home image

Preview: open index.html in a web browser.

FREE HOSTING:
1. Create a GitHub account and a new public repository (e.g. gurpreet-gill-real-estate).
2. Upload index.html and the assets folder, keeping the same folder structure.
3. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
4. GitHub will provide a free public website URL.

LISTING DATA:
This website does not scrape REALTOR.ca or pretend to show live MLS listings. To display live listing photos/details directly on your site, ask your broker of record about permission and apply for an authorized REALTOR.ca DDF® or local-board/approved IDX feed. Do not put API secrets in browser-side code. See the official links below.
- REALTOR.ca DDF: https://www.realtor.ca/ddf
- CREA DDF docs: https://ddfapi-docs.realtor.ca/
- REALTOR.ca terms: https://www.realtor.ca/terms-of-use

Before publishing, confirm all office addresses/phone numbers, branding and advertising disclosures with your brokerage. This site is a starter and has not been reviewed by your broker or lawyer.
